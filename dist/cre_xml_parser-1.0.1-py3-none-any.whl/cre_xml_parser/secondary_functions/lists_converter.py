def get_dict_from_lists(keys_list: list, values_list: list):
    return {key: value for key, value in zip(keys_list, values_list)}
