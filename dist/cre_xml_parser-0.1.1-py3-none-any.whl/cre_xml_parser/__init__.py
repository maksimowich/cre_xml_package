from .loading_to_db import recreate_tables_and_load_xml_files
from .constants import TAG_TO_TABLE_TYPES_DICT

print('x')
